Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnRename As System.Windows.Forms.Button
    Friend WithEvents DirListBox1 As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    Friend WithEvents FileListBox1 As Microsoft.VisualBasic.Compatibility.VB6.FileListBox
    Friend WithEvents DriveListBox1 As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    Friend WithEvents txtRename As System.Windows.Forms.TextBox
    Friend WithEvents lblFilePattern As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnRename = New System.Windows.Forms.Button
        Me.DirListBox1 = New Microsoft.VisualBasic.Compatibility.VB6.DirListBox
        Me.FileListBox1 = New Microsoft.VisualBasic.Compatibility.VB6.FileListBox
        Me.DriveListBox1 = New Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
        Me.txtRename = New System.Windows.Forms.TextBox
        Me.lblFilePattern = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnRename
        '
        Me.btnRename.Location = New System.Drawing.Point(168, 352)
        Me.btnRename.Name = "btnRename"
        Me.btnRename.Size = New System.Drawing.Size(144, 40)
        Me.btnRename.TabIndex = 0
        Me.btnRename.Text = "Rename"
        '
        'DirListBox1
        '
        Me.DirListBox1.IntegralHeight = False
        Me.DirListBox1.Location = New System.Drawing.Point(16, 64)
        Me.DirListBox1.Name = "DirListBox1"
        Me.DirListBox1.Size = New System.Drawing.Size(200, 176)
        Me.DirListBox1.TabIndex = 1
        '
        'FileListBox1
        '
        Me.FileListBox1.Location = New System.Drawing.Point(248, 24)
        Me.FileListBox1.Name = "FileListBox1"
        Me.FileListBox1.Pattern = "*.*"
        Me.FileListBox1.Size = New System.Drawing.Size(216, 212)
        Me.FileListBox1.TabIndex = 3
        '
        'DriveListBox1
        '
        Me.DriveListBox1.Location = New System.Drawing.Point(16, 24)
        Me.DriveListBox1.Name = "DriveListBox1"
        Me.DriveListBox1.Size = New System.Drawing.Size(200, 21)
        Me.DriveListBox1.TabIndex = 4
        '
        'txtRename
        '
        Me.txtRename.Location = New System.Drawing.Point(104, 312)
        Me.txtRename.Name = "txtRename"
        Me.txtRename.Size = New System.Drawing.Size(272, 20)
        Me.txtRename.TabIndex = 5
        Me.txtRename.Text = "command?oldvalue:newvalue"
        Me.txtRename.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblFilePattern
        '
        Me.lblFilePattern.Location = New System.Drawing.Point(104, 272)
        Me.lblFilePattern.Name = "lblFilePattern"
        Me.lblFilePattern.Size = New System.Drawing.Size(272, 24)
        Me.lblFilePattern.TabIndex = 6
        Me.lblFilePattern.Text = "File Pattern"
        Me.lblFilePattern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(480, 406)
        Me.Controls.Add(Me.lblFilePattern)
        Me.Controls.Add(Me.txtRename)
        Me.Controls.Add(Me.DriveListBox1)
        Me.Controls.Add(Me.FileListBox1)
        Me.Controls.Add(Me.DirListBox1)
        Me.Controls.Add(Me.btnRename)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnRename_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRename.Click
        If MsgBox("Are you sure you wish to rename all the files in the File List Box using the pattern specified?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Dim Files() As String = Directory.GetFiles(Me.FileListBox1.Path.ToString)
            Dim MyFile As Object
            Dim MyCommand As String = Me.txtRename.Text.ToString
            Dim Pattern As String = MyCommand.Substring(MyCommand.IndexOf("?") + 1)
            Dim Operation As String = MyCommand.Substring(0, MyCommand.IndexOf("?"))
            Operation = Operation.ToUpper
            Dim NewFileName As String
            For Each MyFile In Files
                Select Case Operation
                    Case "REPLACE"
                        Dim ReplaceValue As String = Pattern.Substring(Pattern.IndexOf(":") + 1)
                        Dim FindValue As String = Pattern.Substring(0, Pattern.IndexOf(":"))
                        NewFileName = Replace(MyFile, FindValue, ReplaceValue)
                        File.Move(MyFile, NewFileName)
                End Select
            Next
            Me.FileListBox1.Refresh()
        End If
    End Sub

    Private Sub DriveListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DriveListBox1.SelectedValueChanged
        Try
            Me.DirListBox1.Path = Me.DriveListBox1.Drive
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DirListBox1_Change(ByVal sender As Object, ByVal e As System.EventArgs) Handles DirListBox1.Change
        Me.FileListBox1.Path = Me.DirListBox1.Path
    End Sub

End Class
